/*
 * Copyright (C) 2020-2023 Roger Clark, VK3KYY / G4KYF
 *                         Daniel Caujolle-Bert, F1RMB
 *
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
 *    in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. Use of this source code or binary releases for commercial purposes is strictly forbidden. This includes, without limitation,
 *    incorporation in a commercial product or incorporation into a product or project which allows commercial use.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "io/rotary_switch.h"

#if defined(PLATFORM_GD77S)
static uint8_t prevPosition;
#endif

void rotarySwitchInit(void)
{
#if defined(PLATFORM_GD77S)
	gpioInitRotarySwitch();

	prevPosition = -1;
#endif
}

uint8_t rotarySwitchGetPosition(void)
{
#if defined(PLATFORM_GD77S)
	static const uint8_t rsPositions[] = { 1, 8, 2, 7, 4, 5, 3, 6, 16, 9, 15, 10, 13, 12, 14, 11 };
	return rsPositions[(~((GPIOD->PDIR) >> 4) & 0x0F)];
#else
	return 0;
#endif
}

void rotarySwitchCheckRotaryEvent(uint32_t *position, int *event)
{
#if ! defined(PLATFORM_GD77S)
	*position = 0;
	*event = EVENT_ROTARY_NONE;
#else
	uint8_t value = rotarySwitchGetPosition();

	*position = value; // set it anyway, as it could be checked even on no event

	if (prevPosition != value)
	{
		*event = EVENT_ROTARY_CHANGE;
		prevPosition = value;
	}
	else
	{
		*event = EVENT_ROTARY_NONE;
	}
#endif
}
