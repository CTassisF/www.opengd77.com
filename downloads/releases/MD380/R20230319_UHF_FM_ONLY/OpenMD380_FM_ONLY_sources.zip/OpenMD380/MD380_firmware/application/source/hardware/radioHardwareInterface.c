/*
 * Copyright (C) 2021-2022 Roger Clark, VK3KYY / G4KYF
 *
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
 *    in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. Use of this source code or binary releases for commercial purposes is strictly forbidden. This includes, without limitation,
 *    incorporation in a commercial product or incorporation into a product or project which allows commercial use.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include <hardware/HRC.h>
#include "hardware/radioHardwareInterface.h"
#include "functions/settings.h"
#include "functions/trx.h"
#include "functions/rxPowerSaving.h"
#if defined(USING_EXTERNAL_DEBUGGER)
#include "SeggerRTT/RTT/SEGGER_RTT.h"
#endif
#include "main.h"

//list of CTCSS tones supported by the HRC6000. These are used to find the index for the tone. The order is critical.
const uint16_t HRC_CTCSSTones[] =
{
		6700,  7190,  7440,  7700,  7970,  8250,  8540,
		8850,  9150,  9480,  9740,  10000, 10350, 10720,
		11090, 11480, 11880, 12300, 12730, 13180, 13650,
		14130, 14620, 15140, 15670, 16220, 16790, 17380,
		17990, 18620, 19280, 20350, 21070, 21810, 22570,
		23360, 24180, 25030, 6930,  6250,  15980, 16550,
		17130, 17730, 18350, 18990, 19660, 19950, 20650,
		22910, 25410
};

static bool audioPathFromFM = true;
static bool ampIsOn = false;

void radioPowerOn(void)
{
	//Turn off Tx Voltage to prevent transmission.

	HAL_GPIO_WritePin(TX_STG_EN_GPIO_Port,TX_STG_EN_Pin, GPIO_PIN_RESET);

	//Turn on receiver voltage.

	HAL_GPIO_WritePin(RX_STG_EN_GPIO_Port,RX_STG_EN_Pin, GPIO_PIN_SET);

	//turn on the 5V

	HAL_GPIO_WritePin(PLL_PWR_GPIO_Port,PLL_PWR_Pin, GPIO_PIN_SET);

	//Turn on the DMR Audio stages (needed for melody)

	HAL_GPIO_WritePin(DMR_SW_GPIO_Port,DMR_SW_Pin, GPIO_PIN_SET);

	//Turn on the Microphone power

	HAL_GPIO_WritePin(MICPWR_SW_GPIO_Port,MICPWR_SW_Pin, GPIO_PIN_SET);

}

void radioPowerOff(bool invalidateFrequency)
{
	//Turn off Tx and Rx Voltages.

	HAL_GPIO_WritePin(TX_STG_EN_GPIO_Port,TX_STG_EN_Pin, GPIO_PIN_RESET);

	HAL_GPIO_WritePin(RX_STG_EN_GPIO_Port,RX_STG_EN_Pin, GPIO_PIN_RESET);

	//turn off the 5V

	HAL_GPIO_WritePin(PLL_PWR_GPIO_Port,PLL_PWR_Pin, GPIO_PIN_RESET);

	if (invalidateFrequency)
	{
		trxInvalidateCurrentFrequency();
	}
}


void radioInit(void)
{

}

void radioPostinit(void)
{

}

void radioSetBandwidth(bool Is25K)
{
	HAL_GPIO_WritePin(W_N_SW_GPIO_Port, W_N_SW_Pin, Is25K);
}

void radioSetCalibration(void)
{

}

void radioSetMode(int mode)
{
	switch (mode)
	{
		case RADIO_MODE_ANALOG:
			HAL_GPIO_WritePin(FM_SW_GPIO_Port, FM_SW_Pin, GPIO_PIN_SET); 			//Turn on the FM audio stages
			hrcSetFMRx();
			break;
		case RADIO_MODE_DIGITAL:
			HAL_GPIO_WritePin(FM_SW_GPIO_Port, FM_SW_Pin, GPIO_PIN_RESET); 			//Turn off the FM Audio Stages
			HAL_GPIO_WritePin(FM_MUTE_GPIO_Port, FM_MUTE_Pin, GPIO_PIN_RESET);		//Mute The FM Audio
			hrcSetDMR();
			break;
		case RADIO_MODE_NONE:
			HAL_GPIO_WritePin(FM_SW_GPIO_Port, FM_SW_Pin, GPIO_PIN_RESET); 			//Turn off the FM Audio Stages
			break;
	}
}


void radioSetIF(int band, bool wide)
{
	//we dont need to do anything on the MD380 apart from setting the bandwidth
   radioSetBandwidth(wide);
}

void IFTransfer(bool band, uint16_t data1)
{


}



//This is for the SKY Synthesiser
void radioSetFrequency(uint32_t freq, bool Tx)
{
	uint16_t refdiv;
	uint32_t ref;
	uint16_t N;
	uint32_t rem;
	uint32_t frac;

	//don't really need these register variables, could send them directly to the SPI but they make debugging easier for now.

	uint16_t reg0;
	uint16_t reg1;
	uint16_t reg2;
	uint16_t reg5;
	uint16_t reg6;
	uint16_t reg7;
	uint16_t reg8;
	uint16_t reg9;


	if (!Tx)				//if this is for the Receiver then subtract the IF Frequency of 49.95 MHz to get the LO frequency
	{
		freq = freq - 4995000;
	}
	refdiv = 4;



	ref = 1680000 / refdiv;        //16.8 MHz reference Oscillator
	N = freq / ref;
	rem = freq % ref;
	frac = ((uint64_t)rem * 262144) / ref;

	if (frac > 131071)     //if the fractional part is more than 0.5 then increase the Integer. The fractional part is then taken as a negative offset. (thats the way the SKY chip works!)
	{
		N = N + 1;
	}

	//generate the register values add the non-changing values for regs 6-9

	reg0 = N - 32;
	reg1 = frac >> 8;
	reg2 = frac & 0xFF;
	reg5 = refdiv - 1;
	reg6 = 0x001F;
	reg7 = 0x03D0;
	reg8 = 0x0000;
	reg9 = 0x0000;


	if (Tx)
	{
		HAL_GPIO_WritePin(VCOVCC_SW_GPIO_Port, VCOVCC_SW_Pin, GPIO_PIN_RESET);
	}
	else
	{
		HAL_GPIO_WritePin(VCOVCC_SW_GPIO_Port, VCOVCC_SW_Pin, GPIO_PIN_SET);
	}


	//now send the register values to the Synthesiser chip. This is the order they are sent by the TYT firmware.

	SynthTransfer(8, reg8);
	SynthTransfer(9, reg9);
	SynthTransfer(5, reg5);
	SynthTransfer(0, reg0);
	SynthTransfer(2, reg2);
	SynthTransfer(1, reg1);
	SynthTransfer(6, reg6);
	SynthTransfer(7, reg7);

	//As we have just changed the frequency we should also output the relevant tuning voltages.

	if (Tx) 						//We have just set the Tx frequency so we are about to transmit. Set the Tx Power Control DAC (Shared with VHF Receive Tuning)
	{
		dac_Out(1, txDACDrivePower);
	}
	else						//if we have just set the Rx Frequency then set the relevant Front End Tuning Voltage.
	{
	    dac_Out(1, UHFRxTuningVolts);
	}

}

//send the 16 bit value to the Sky Synthesiser (uses the same CLK and DATA pins as the HRC6000
void SynthTransfer(uint8_t add, uint16_t data1)
{
	data1 = data1 | (add << 12);


	//set the CE low
	HAL_GPIO_WritePin(PLL_CS_GPIO_Port, PLL_CS_Pin, GPIO_PIN_RESET);

	//Send the data as 16 bits of SPI
	for (register int i = 0; i < 16; i++)
	{
		HAL_GPIO_WritePin(PLL_CLK_GPIO_Port, PLL_CLK_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(DMR_SPI_MOSI_GPIO_Port, DMR_SPI_MOSI_Pin, ((data1 & 0x8000) != 0));
		data1 = data1 << 1;
		HAL_GPIO_WritePin(PLL_CLK_GPIO_Port, PLL_CLK_Pin, GPIO_PIN_SET);
	}
	//set the CS High Again
	HAL_GPIO_WritePin(PLL_CS_GPIO_Port, PLL_CS_Pin, GPIO_PIN_SET);

}


void radioSetTx(uint8_t band)
{
	//Turn off receiver voltage.
	HAL_GPIO_WritePin(RX_STG_EN_GPIO_Port,RX_STG_EN_Pin, GPIO_PIN_RESET);

	//Configure HRC-6000 for transmit
	if (trxGetMode() == RADIO_MODE_ANALOG)
	{
		hrcSetFMTx();
	}
	else
	{
		hrcSetDMR();
	}

	//Turn on Tx Voltage.

	HAL_GPIO_WritePin(TX_STG_EN_GPIO_Port,TX_STG_EN_Pin, GPIO_PIN_SET);

	//Turn on the power control circuit

	HAL_GPIO_WritePin(RF_APC_SW_GPIO_Port, RF_APC_SW_Pin, GPIO_PIN_SET);
	trxIsTransmitting = true;
}

//just enable or disable the RF output . doesn't change back to receive
void radioFastTx(bool tx)
{
	if(tx)
	{
		//Turn on the Tx Voltage
		HAL_GPIO_WritePin(TX_STG_EN_GPIO_Port,TX_STG_EN_Pin, GPIO_PIN_SET);

		//Turn on the power control circuit
	   HAL_GPIO_WritePin(RF_APC_SW_GPIO_Port, RF_APC_SW_Pin, GPIO_PIN_SET);
	}
	else
	{
		//Turn off the power control circuit
		HAL_GPIO_WritePin(RF_APC_SW_GPIO_Port, RF_APC_SW_Pin, GPIO_PIN_RESET);

		//Turn off Tx Voltage to prevent transmission.
		HAL_GPIO_WritePin(TX_STG_EN_GPIO_Port,TX_STG_EN_Pin, GPIO_PIN_RESET);

	}

}

void radioSetRx(uint8_t band)
{
	//Turn off the power control circuit
	HAL_GPIO_WritePin(RF_APC_SW_GPIO_Port, RF_APC_SW_Pin, GPIO_PIN_RESET);

	//Turn off the Tx Voltage

	HAL_GPIO_WritePin(TX_STG_EN_GPIO_Port,TX_STG_EN_Pin, GPIO_PIN_RESET);

	//Turn off the power control circuit

	HAL_GPIO_WritePin(RF_APC_SW_GPIO_Port, RF_APC_SW_Pin, GPIO_PIN_RESET);

	//Turn on receiver voltage.

	HAL_GPIO_WritePin(RX_STG_EN_GPIO_Port,RX_STG_EN_Pin, GPIO_PIN_SET);


	trxIsTransmitting = false;
	if (trxGetMode() == RADIO_MODE_ANALOG)
	{
		hrcSetFMRx();
	}
	else
	{
		hrcSetDMR();
	}

}


void radioReadVoxAndMicStrength(void)
{
	trxTxVox = adcGetVOX();
	trxTxMic = trxTxVox;					//MD9600 doesn't have separate Signals so use Vox for both.
}

void radioReadRSSIAndNoiseForBand(uint8_t band)
{
		trxRxSignal = adcGetRSSI();
		trxRxNoise = adcGetNoise();
	trxDMRSynchronisedRSSIReadPending = false;
}

void radioReadRSSIAndNoise()
{
	radioReadRSSIAndNoiseForBand(trxCurrentBand[TRX_RX_FREQ_BAND]);
}

void radioRxCSSOff(void)
{
	//turn off the receive CTCSS detection;
	//don't really need to do anything here, the decode runs all of the time anyway
}
static int getCSSToneIndex(uint16_t tone)
{
	//the TYT firmware uses a PWM output to directly generate the CTCSS Tone.
	//however the HR-C6000 can also generate tones so we will use that instead
	//this uses a table so we need to convert the CTCSS tone to the Table Index.
	uint8_t HRCToneIndex = 1;

	for (int i = 0; i < ARRAY_SIZE(HRC_CTCSSTones); i++)
	{
		if (HRC_CTCSSTones[i] == tone)
		{
			HRCToneIndex = i + 1;
			break;
		}
	}

	return HRCToneIndex;
}

void radioRxCSSOn(uint16_t tone)
{
	hrcSetRxCTCSS(getCSSToneIndex(tone));
}

void radioRxDCSOn(uint16_t code, bool inverted)
{
	hrcSetRxDCS(code, inverted);
}

void radioTxCSSOff(void)
{
	hrcSetTxCTCSS(0);
}

void radioTxCSSOn(uint16_t tone)
{
	hrcSetTxCTCSS(getCSSToneIndex(tone));
}

void radioTxDCSOn(uint16_t code, bool inverted)
{
	hrcSetTxDCS(code, inverted);
}

bool radioCheckCSS(void)
{
//test if CTCSS or DCS is being received and return true if it is
	return hrcCheckCSS();
}

void radioSetTone1(int tonefreq)
{
	hrcSendTone(tonefreq);
}


void radioSetMicGainFM(uint8_t gain)
{
	hrcSetMicGain(gain);
}

void radioSetMicGainDMR(uint8_t gain)
{
	hrcSetMicGain(gain);
}

void radioSetAudioMutePWM(uint32_t val)
{
	TIM_OC_InitTypeDef sConfigOC;
	sConfigOC.OCMode = TIM_OCMODE_PWM1;
	sConfigOC.Pulse = val;
	sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
	HAL_TIM_PWM_Stop(&htim4, TIM_CHANNEL_1);
	HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
}

void radioAudioAmp(bool on)
{

	if (on)
	{
//		radioSetAudioMutePWM(0);
		HAL_GPIO_WritePin(AUDIO_AMP_EN_GPIO_Port, AUDIO_AMP_EN_Pin, GPIO_PIN_SET);				//Turn on the audio amp.
		HAL_GPIO_WritePin(SPK_MUTE_GPIO_Port, SPK_MUTE_Pin, GPIO_PIN_RESET);						//unmute the speaker


		if (audioPathFromFM)
		{
			hrcSetLineOut(false);													//Disable the Line Output
			HAL_GPIO_WritePin(FM_SW_GPIO_Port, FM_SW_Pin, GPIO_PIN_SET);				//Turn on the FM audio circuits
			HAL_GPIO_WritePin(FM_MUTE_GPIO_Port, FM_MUTE_Pin, GPIO_PIN_SET);		    //Unmute the FM Audio to the volume control

		}
		else
		{
			HAL_GPIO_WritePin(FM_SW_GPIO_Port, FM_SW_Pin, GPIO_PIN_RESET);				//Turn off the FM audio circuits
			HAL_GPIO_WritePin(FM_MUTE_GPIO_Port, FM_MUTE_Pin, GPIO_PIN_RESET);		    //Mute the FM Audio to the volume control
			hrcSetLineOut(true);													//Enable the Line Output
		}
		ampIsOn = true;
	}
	else
	{
//		radioSetAudioMutePWM(settingsIsOptionBitSet(BIT_SPEAKER_CLICK_SUPPRESS)?MIN_PWM_VALUE_TO_MUTE_AUDIO:MAX_PWM_VALUE);

		HAL_GPIO_WritePin(AUDIO_AMP_EN_GPIO_Port, AUDIO_AMP_EN_Pin, GPIO_PIN_RESET);				//Turn off the audio amp.
		HAL_GPIO_WritePin(SPK_MUTE_GPIO_Port, SPK_MUTE_Pin, GPIO_PIN_SET);						//mute the speaker
		HAL_GPIO_WritePin(FM_MUTE_GPIO_Port, FM_MUTE_Pin, GPIO_PIN_RESET);			        //Mute the FM audio to the volume control (we can always do this regardless of the actual audio source)
		hrcSetLineOut(false);															//Disable the Line Output
		ampIsOn = false;
	}

}

void radioSetAudioPath(bool fromFM)
{
	audioPathFromFM = fromFM;

	if (ampIsOn)												//if the audio source is being changed while the amplifier is on then we need to update the audio amp control
	{
		radioAudioAmp(true);
	}
}
