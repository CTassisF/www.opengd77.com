/*
 * Copyright (C) 2021-2022 Roger Clark, VK3KYY / G4KYF
 *                         Colin Durbridge, G4EML
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
 *    in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. Use of this source code or binary releases for commercial purposes is strictly forbidden. This includes, without limitation,
 *    incorporation in a commercial product or incorporation into a product or project which allows commercial use.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
#include "main.h"
#include "user_interface/uiGlobals.h"
#include "user_interface/uiUtilities.h"
#include "interfaces/gps.h"

#define GPS_DMA_BUFFER_SIZE     64U
#define GPS_LINE_LENGTH         80U

gpsData_t gpsData =
{
		.IsFitted = false,
		.DataAvailable = false,
		.Latitude = 0U,
		.Longitude = 0U,
		.SatsInView = 0U,
		.Time = 0U
};

static char gpsLine[GPS_LINE_LENGTH] = {0};
static uint8_t gpsRxBuf[GPS_LINE_LENGTH] = {0};
static bool gpsLineReady;
static uint8_t gpsDMABuf[GPS_DMA_BUFFER_SIZE]; // double buffer (two halves) for GPS UART DMA receive
static size_t gpsCharPointer;

// converts the GPS data from the format DDDmm.mmmm   into our custom format Int<<23  + frac*1000
//assumes no leading or trailing spaces
static uint32_t gpsLatLongConvert(const char *input)
{
	uint32_t degrees;
	uint32_t minutes;
	uint8_t decimalpoint = 0;
	uint8_t digitsbeforepoint = 0;
	uint8_t digitsafterpoint = 0;

	for (size_t i = 0; i < strlen(input); i++)					//find the position of the decimal point
	{
		if (input[i] == '.')
		{
			decimalpoint = i;
		}

		if ((input[i] > 47) && (input[i] < 58))					//count the digits
		{
			if (decimalpoint > 0)
			{
				digitsafterpoint++;
			}
			else
			{
				digitsbeforepoint++;
			}
		}
	}

	degrees = 0;
	minutes = 0;
	if(digitsbeforepoint > 4)						//this is a latitude
	{
		degrees = (input[decimalpoint - 5] - 48) * 100;
	}

	if (digitsbeforepoint > 3)
	{
		degrees = degrees + ((input[decimalpoint - 4] - 48) * 10);
	}

	if (digitsbeforepoint > 2)
	{
		degrees = degrees + (input[decimalpoint - 3] - 48);
	}

	if (digitsbeforepoint > 1)
	{
		minutes = (input[decimalpoint - 2] - 48) * 10000;
	}

	if (digitsbeforepoint > 0)
	{
		minutes = minutes + ((input[decimalpoint - 1] - 48) * 1000);
	}

	if (digitsafterpoint > 0)
	{
		minutes = minutes + ((input[decimalpoint + 1] - 48) * 100);
	}

	if (digitsafterpoint > 1)
	{
		minutes = minutes + ((input[decimalpoint + 2] - 48) * 10);
	}

	if (digitsafterpoint > 2)
	{
		minutes = minutes + (input[decimalpoint + 3] - 48);
	}

	return (degrees << 23) + (minutes / 60);
}

static time_t_custom gpsTimeConvert(const char *time, const char *date)
{
	struct tm gpsDateTime;
	uint8_t Date;
	uint8_t Month;
	uint8_t Year;
	uint8_t Hours;
	uint8_t Minutes;
	uint8_t Seconds;

	if (strlen(date) == 6)
	{
		Year = ((date[4] - 48) * 10) + (date[5] - 48);
		Month = ((date[2] - 48) * 10) + (date[3] - 48);
		Date = ((date[0] - 48) * 10) + (date[1] - 48);
	}
	else
	{
		Year = 21;
		Month = 12;
		Date = 25;
	}

	if (Year < 70)
	{
		Year = Year + 100;
	}

	if (strlen(time) >= 6)
	{
		Seconds = ((time[4] - 48) * 10) + (time[5] - 48);
		Minutes = ((time[2] - 48) * 10) + (time[3] - 48);
		Hours = ((time[0] - 48) * 10) + (time[1] - 48);
	}
	else
	{
		Seconds = 0;
		Minutes = 0;
		Hours = 0;
	}

	memset(&gpsDateTime, 0x00, sizeof(struct tm)); // clear entire struct
	gpsDateTime.tm_mday = Date;          /* day of the month, 1 to 31 */
	gpsDateTime.tm_mon = Month - 1;      /* months since January, 0 to 11 */
	gpsDateTime.tm_year = Year;          /* years since 1900 */
	gpsDateTime.tm_hour = Hours;
	gpsDateTime.tm_min = Minutes;
	gpsDateTime.tm_sec = Seconds;

	return mktime_custom(&gpsDateTime);
}

static void getParam(const char *line, char *result, int entryno, int reslen)
{
	int count = 0;
	int respoint = 0;

	for (size_t i = 0; i < strlen(line); i++)
	{
		if (line[i] == ',')
		{
			count++;
			if (count == entryno)
			{
				result[respoint] = 0;
				return;
			}
			else
			{
				respoint = 0;
			}
		}
		else
		{
			result[respoint++] = line[i];
			if (respoint > reslen - 1)
			{
				result[0] = 0;
				return;
			}
		}
	}

	result[0] = 0;
}

static void gpsProcessChar(uint8_t rxchar)
{
	if ((rxchar != 13) && (gpsCharPointer < (GPS_LINE_LENGTH - 2)))
	{
		if (rxchar > 32)
		{
			gpsRxBuf[gpsCharPointer++] = rxchar;
		}
	}
	else
	{
		gpsRxBuf[gpsCharPointer] = 0;
		memcpy(gpsLine, gpsRxBuf, gpsCharPointer + 1);
		gpsCharPointer = 0;
		gpsLineReady = true;
	}
}

void gpsOn(void)
{
	gpsCharPointer = 0U;
	gpsLineReady = false;
	gpsData.DataAvailable = false;

	HAL_UART_Receive_DMA(
#if defined(PLATFORM_MD9600) || defined(PLATFORM_MDUV380)
			&huart1
#elif defined(PLATFORM_MD380)
			&huart3
#endif
			, gpsDMABuf, GPS_DMA_BUFFER_SIZE);
}

void gpsOff(void)
{
	gpsCharPointer = 0U;
	gpsLineReady = false;
	gpsData.DataAvailable = false;

	HAL_UART_DMAStop(
#if defined(PLATFORM_MD9600) || defined(PLATFORM_MDUV380)
			&huart1
#elif defined(PLATFORM_MD380)
			&huart3
#endif
			);
}

void HAL_UART_RxHalfCpltCallback(UART_HandleTypeDef *huart)
{
	for (size_t i = 0; i < 32; i++)
	{
		gpsProcessChar(gpsDMABuf[i]);
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	for (size_t i = 0; i < 32; i++)
	{
		gpsProcessChar(gpsDMABuf[(GPS_DMA_BUFFER_SIZE / 2) + i]);
	}
}

#if defined(PLATFORM_MD9600)
//turn the GPS on and off. Note this also turns the Microphone power on and off, so the GPS must always be On when the radio is in use.
void gpsAndMicPower(bool on)
{
	if (on)
	{
		GPIOA->MODER = (GPIOA->MODER & ~GPIO_MODER_MODER9_Msk) | GPIO_MODER_MODER9_0;     //Set the GPIOA Pin 9 to GPIO mode
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_SET);                               //set it high
	}
	else
	{
		GPIOA->MODER = (GPIOA->MODER & ~GPIO_MODER_MODER9_Msk) | GPIO_MODER_MODER9_0;     // Set the GPIOA Pin 9 to GPIO mode
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_RESET);                             //set it Low
	}
}
#elif defined(PLATFORM_MD380) || defined(PLATFORM_MDUV380)
void gpsPower(bool on)
{
	if (on)
	{
#if defined(PLATFORM_MD380)
		GPIOD->MODER = (GPIOD->MODER & ~GPIO_MODER_MODER8_Msk) | GPIO_MODER_MODER8_0;     //Set the GPIOD Pin 8 to GPIO mode
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_8, GPIO_PIN_SET);                               //set it high
#else
		GPIOA->MODER = (GPIOA->MODER & ~GPIO_MODER_MODER9_Msk) | GPIO_MODER_MODER9_0;     //Set the GPIOA Pin 9 to GPIO mode
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_SET);                               //set it high
#endif
	}
	else
	{
#if defined(PLATFORM_MD380)
		GPIOD->MODER = (GPIOD->MODER & ~GPIO_MODER_MODER8_Msk) | GPIO_MODER_MODER8_0;     // Set the GPIOD Pin 8 to GPIO mode
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_8, GPIO_PIN_RESET);                             //set it Low
#else
		GPIOA->MODER = (GPIOA->MODER & ~GPIO_MODER_MODER9_Msk) | GPIO_MODER_MODER9_0;     // Set the GPIOA Pin 9 to GPIO mode
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_RESET);                             //set it Low
#endif
	}
}
#endif

void gpsTick(void)
{
	char param[6][20];

	if (gpsLineReady)
	{
		//USB_DEBUG_printf("%s\n", gpsLine);
		if (strstr(gpsLine, "$GPRMC") != NULL)			//is this the LAT Long and Time Message?
		{						//if we have received the message then we must have a GPS module fitted.
			getParam(gpsLine, param[0] , 2, 20);			//get parameter 2 which is GMT Time as hhmmss.sss
			getParam(gpsLine, param[1] , 4, 20);			//get parameter 4 which is Latitude a ddmm.mmmm
			getParam(gpsLine, param[2] , 5, 20);			//get parameter 5 which is N/S
			getParam(gpsLine, param[3] , 6, 20);			//get parameter 6 which is Longitude a dddmm.mmmm
			getParam(gpsLine, param[4] , 7, 20);			//get parameter 7 which is E/W
			getParam(gpsLine, param[5] , 10, 20);	    //get parameter 10 which is Date as ddmmyy

			if (strlen(param[1]) == 0)
			{
				strcpy(param[1], "0000.000");
			}

			gpsData.Latitude = gpsLatLongConvert(param[1]);

			if (strstr(param[2], "S") != NULL)
			{
				gpsData.Latitude = gpsData.Latitude | 0x80000000;
			}

			if (strlen(param[3]) == 0)
			{
				strcpy(param[3], "00000.000");
			}

			gpsData.Longitude = gpsLatLongConvert(param[3]);

			if (strstr(param[4], "W") != NULL)
			{
				gpsData.Longitude = gpsData.Longitude | 0x80000000;
			}

			gpsData.Time = gpsTimeConvert(param[0], param[5]);
			gpsData.DataAvailable = true;
			gpsData.IsFitted = true;
		}
		else if (strstr(gpsLine, "$GPGSV") != NULL)			//is this the Sat View Message?
		{
			getParam(gpsLine, param[0], 4, 20);			//get parameter 4 which is the number of Sats in view
			gpsData.SatsInView = atoi(param[0]);
		}

		gpsLineReady = false;
	}
}
