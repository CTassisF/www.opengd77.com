/*
 * Copyright (C) 2019      Kai Ludwig, DG4KLU
 * Copyright (C) 2019-2022 Roger Clark, VK3KYY / G4KYF
 *                         Daniel Caujolle-Bert, F1RMB
 *
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer
 *    in the documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. Use of this source code or binary releases for commercial purposes is strictly forbidden. This includes, without limitation,
 *    incorporation in a commercial product or incorporation into a product or project which allows commercial use.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
 * USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "utils.h"
#include "functions/calibration.h"
#include "functions/trx.h"

const int MAX_PA_DAC_VALUE = 4095;

typedef struct
{
//0x00
	uint8_t VoxLevel1;				//calibration for Vox Setting 1
	uint8_t VoxLevel10;				//calibration for Vox Setting 10
	uint8_t RxLowVoltage;			//Exact use unknown
	uint8_t RxHighVoltage;			//Exact use unknown
	uint8_t RSSI120;			    //RSSI Calibration for -120dBm
	uint8_t RSSI70;					//RSSI Calibration for -70dBm
	uint8_t FM_Mic;					//FM MIc Gain
	uint8_t DMR_Mic;					//DMR MIc Gain
//0x08
	uint8_t OscRefTuneHigh;			//Reference Oscillator tuning for positive shift
	uint8_t OscRefTuneMid;			//Nominal Reference Oscillator tuning
	uint8_t OscRefTuneLow;			//Reference Oscillator tuning for negative shift
	uint8_t UnknownBlock3[5];		//Unknown
//0x10
	uint8_t HighPowerCal[9];	    //High Power Calibration 9 frequencies
//0x19
	uint8_t UnknownBlock4[7];		//Unknown
//0x20
	uint8_t LowPowerCal[9];		    //Low Power Calibration 9 frequencies
//0x29
	uint8_t UnknownBlock5[7];		//Unknown
//0x30
	uint8_t RxTuning[9];		    //UHF Front End Tuning 9 frequencies
//0x39
	uint8_t UnknownBlock6[7];		//Unknown
//0x40
	uint8_t OpenSquelch9[9];        //UHF Level 9 Opening  9 frequencies
//0x49
	uint8_t UnknownBlock7[7];		//Unknown
//0x50
	uint8_t CloseSquelch9[9];       //Squelch Level 9 Closing 9 frequencies
//0x59
	uint8_t UnknownBlock8[7];		//Unknown
//0x60
	uint8_t OpenSquelch1[9];        //Squelch Level 1 Opening  9 frequencies
//0x69
	uint8_t UnknownBlock9[7];		//Unknown
//0x70
	uint8_t CloseSquelch1[9];       //Squelch Level 1 Closing 9 frequencies
//0x79
	uint8_t UnknownBlock10[7];		//Unknown
//0x80
	uint8_t MaxVolume[9];		    //Maximum volume setting
//0x89
	uint8_t UnknownBlock11[7];		//Unknown
//0x90
	uint8_t CTC67[9];			    //CTCSS Deviation for 67Hz Tone 9 frequencies
//0x99
	uint8_t UnknownBlock12[7];		//Unknown
//0xA0
	uint8_t CTC151[9];			    //CTCSS Deviation for 151.4Hz Tone 9 frequencies
//0xA9
	uint8_t UnknownBlock13[7];		//Unknown
//0xB0
	uint8_t CTC254[9];			    //CTCSS Deviation for 254.1Hz Tone 9 frequencies
//0xB9
	uint8_t UnknownBlock14[7];		//Unknown
//0xC0
	uint8_t DCSMOD2[9];		        //DCS MOD2 setting?
//0xC9
	uint8_t UnknownBlock15[7];		//Unknown
//0xD0
	uint8_t DCSMOD1[9];				//DCS Mod1 setting?
//0xD9
	uint8_t UnknownBlock16[7];		//Unknown
//0xE0
	uint8_t MOD1Partial[9];		    //Always set to 0x80
//0xE9
	uint8_t UnknownBlock17[7];		//Unknown
//0xF0
	uint8_t AnalogVoiceAdjust[9];	//All set to 0x1E
//0xF9
	uint8_t UnknownBlock18[7];		//Unknown
//0x100
	uint8_t LockVoltagePartial[9];	// All set to Zero
//0x109
	uint8_t UnknownBlock19[7];		//Unknown
//0x110
	uint8_t SendIPartialPartial[9];	// All set to Zero
//0x119
	uint8_t UnknownBlock20[7];		//Unknown
//0x120
	uint8_t SendQPartialPartial[9];	// All set to Zero
//0x129
	uint8_t UnknownBlock21[7];		//Unknown
//0x130
	uint8_t DMRIGain[9];			//I Gain for DMR	9 Frequencies
//0x139
	uint8_t UnknownBlock22[7];		//Unknown
//0x140
	uint8_t DMRQGain[9];			//Q Gain for DMR	9 Frequencies
//0x149
	uint8_t UnknownBlock23[7];		//Unknown
//0x150
	uint8_t RxIPartial[9];			//All Zeros
//0x159
	uint8_t UnknownBlock24[7];		//Unknown
//0x160
	uint8_t RxQPartial[9];			//All Zeros
//0x169
	uint8_t UnknownBlock25[7];		//Unknown
//0x170
	uint8_t FMIGain[9];			   //I Gain for FM	9 Frequencies
//0x179
	uint8_t UnknownBlock26[7];		//Unknown
//0x180
	uint8_t FMQGain[9];			    //Q Gain for FM	9 Frequencies
//0x189
	uint8_t UnknownBlock27[7];		//Unknown
//0x190
	uint8_t UnknownBlock28[32];		//Unused
//0x1B0
	uint8_t TestFreqs[72];			//test frequency Pairs Rx and Tx 4 Bytes BCD Coded LSB First
//0x1F8
	uint8_t UnknownBlock29[8];		//unused
//0x200
} CalibrationData_t;




#define CALIBRATION_TABLE_LENGTH 0x200 // Calibration table is 512 bytes long
static __attribute__((section(".ccmram"))) CalibrationData_t calibrationData;


bool calibrationInit(void)
{
	return (SPI_Flash_readSecurityRegisters(0,(uint8_t *)&calibrationData, CALIBRATION_TABLE_LENGTH));
}

bool calibrationGetSectionData(CalibrationBand_t band, CalibrationSection_t section, CalibrationDataResult_t *o)
{
	switch(section)
	{

		case CalibrationSection_TWOPOINT_MOD:

			o->value = calibrationData.OscRefTuneMid << 2 ;
			break;

		/*
		 *
		 * Sent to the HRC6000 register 0x04 which is the offset value for the Mod 2 output.
		 * However according to the schematics the Mod 2 output is not connected.
		 * Therefore the function of this setting is unclear. (possible datasheet error?)
		 *
		 */
		case CalibrationSection_Q_MOD2_OFFSET:
			// The Cal table has one entry for each band and this is almost identical to 0x47 above.
//			o->value = calibrationData.band[band].QMod2Offset;
			break;

		/*
		 * Sent to the HRC6000 register 0x46. This adjusts the level of the DMR Modulation on the MOD1 output.
		 * Mod 1 controls the AT1846 Reference oscillator so this is effectively the deviation setting for DMR.
		 * Because it modulates the reference oscillator the deviation will change depending on the frequency being used.
		 *
		 * Only affects DMR Transmit. The Cal table has 8 calibration values for each band.
		 */
		case CalibrationSection_PHASE_REDUCE:
			if (o->offset >= 8)
			{
				o->value = 0;
				return false;
			}
//			o->value = calibrationData.band[band].Dmr4FskDeviation[o->offset];
			break;

		default:
			return false;
	}

	return true;
}

//look up the tuning voltage and interpolate between points
uint16_t calibrationGetRxTuneForFrequency(int freq)
{
	int index;
	int offset;
	int limit;
	int upper;
	int lower;

		index = (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) / 1000000;
		offset= (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) % 1000000;
		limit = 8;
		index = CLAMP(index, 0, limit);
		lower = calibrationData.RxTuning[index] << 4;					//get the lower lookup point and scale it to 12 bits
		if(index < limit)
		{
			upper = calibrationData.RxTuning[index + 1] << 4;				//get the higher lookup point and scale it to 12 bits
		}
		else
		{
			upper = lower + (lower - (calibrationData.RxTuning[index - 1] << 4));       //extrapolate outside top point using the same slope
		}

		return CLAMP(interpolate(lower, upper, offset, 1000000), 0, 4095);

}

uint8_t calibrationGetAnalogIGainForFrequency(int freq)
{
	int index;
	int offset;
	int limit;
	int upper;
	int lower;

		index = (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) / 1000000;
		offset= (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) % 1000000;
		limit = 8;
		index = CLAMP(index, 0, limit);
		lower = calibrationData.FMIGain[index];					//get the lower lookup point and scale it to 12 bits
		if(index < limit)
		{
			upper = calibrationData.FMIGain[index + 1];				//get the higher lookup point and scale it to 12 bits
		}
		else
		{
			upper = lower + (lower - (calibrationData.FMIGain[index - 1]));       //extrapolate outside top point using the same slope
		}

		return CLAMP(interpolate(lower, upper, offset, 1000000), 0, 255);

}

uint8_t calibrationGetAnalogQGainForFrequency(int freq)
{
	int index;
	int offset;
	int limit;
	int upper;
	int lower;

		index = (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) / 1000000;
		offset= (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) % 1000000;
		limit = 8;
		index = CLAMP(index, 0, limit);
		lower = calibrationData.FMQGain[index];					//get the lower lookup point and scale it to 12 bits
		if(index < limit)
		{
			upper = calibrationData.FMQGain[index + 1];				//get the higher lookup point and scale it to 12 bits
		}
		else
		{
			upper = lower + (lower - (calibrationData.FMQGain[index - 1]));       //extrapolate outside top point using the same slope
		}

		return CLAMP(interpolate(lower, upper, offset, 1000000), 0, 255);

}


uint8_t calibrationGetDigitalIGainForFrequency(int freq)
{
	int index;
	int offset;
	int limit;
	int upper;
	int lower;


		index = (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) / 1000000;
		offset= (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) % 1000000;
		limit = 8;
		index = CLAMP(index, 0, limit);
		lower = calibrationData.DMRIGain[index];					//get the lower lookup point and scale it to 12 bits
		if(index < limit)
		{
			upper = calibrationData.DMRIGain[index + 1];				//get the higher lookup point and scale it to 12 bits
		}
		else
		{
			upper = lower + (lower - (calibrationData.DMRIGain[index - 1]));       //extrapolate outside top point using the same slope
		}

		return CLAMP(interpolate(lower, upper, offset, 1000000), 0, 255);

}

uint8_t calibrationGetDigitalQGainForFrequency(int freq)
{
	int index;
	int offset;
	int limit;
	int upper;
	int lower;

		index = (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) / 1000000;
		offset= (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) % 1000000;
		limit = 8;
		index = CLAMP(index, 0, limit);
		lower = calibrationData.DMRQGain[index];					//get the lower lookup point and scale it to 12 bits
		if(index < limit)
		{
			upper = calibrationData.DMRQGain[index + 1];				//get the higher lookup point and scale it to 12 bits
		}
		else
		{
			upper = lower + (lower - (calibrationData.DMRQGain[index - 1]));       //extrapolate outside top point using the same slope
		}

		return CLAMP(interpolate(lower, upper, offset, 1000000), 0, 255);



}



int interpolate(int lowerpoint, int upperpoint, int numerator, int denominator)
{
	return lowerpoint + (((upperpoint - lowerpoint) * numerator) / denominator);
}

void calibrationGetPowerForFrequency(int freq, calibrationPowerValues_t *powerSettings)
{
	int index;
	int offset;
	int limit;
	int upper;
	int lower;

		index = (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) / 1000000;
		offset= (freq - RADIO_HARDWARE_FREQUENCY_BANDS[RADIO_BAND_UHF].calTableMinFreq) % 1000000;
		limit = 8;
		index = CLAMP(index, 0, limit);

		lower = calibrationData.LowPowerCal[index] << 4;				// get the Lower lookup point and scale it to 12 bits
		if(index < limit)
		{
			upper = calibrationData.LowPowerCal[index +1] << 4;			//get the higher lookup point and scale it to 12 bits
		}
		else
		{
			upper = lower + (lower - (calibrationData.LowPowerCal[index - 1] << 4));       //extrapolate outside top point using the same slope
		}
		powerSettings->lowPower = CLAMP(interpolate(lower, upper, offset, 1000000), 0, 4096);


		lower = calibrationData.HighPowerCal[index] << 4;				// get the Lower lookup point and scale it to 12 bits
		if(index < limit)
		{
			upper = calibrationData.HighPowerCal[index +1] << 4;			//get the higher lookup point and scale it to 12 bits
		}
		else
		{
			upper = lower + (lower - (calibrationData.HighPowerCal[index - 1] << 4));       //extrapolate outside top point using the same slope
		}
		powerSettings->highPower = CLAMP(interpolate(lower, upper, offset, 1000000), 0, 4096);



}

int8_t calibrationGetMod2Offset(int band)
{

	return calibrationData.OscRefTuneMid - 128;

}

bool calibrationGetRSSIMeterParams(calibrationRSSIMeter_t *rssiMeterValues)
{
	rssiMeterValues->minVal = calibrationData.RSSI120;
	rssiMeterValues->rangeVal = calibrationData.RSSI70;
    return true;
}
