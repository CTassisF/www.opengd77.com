#!/usr/bin/env bash

LANGUAGES="$(ls -d languages/*/)"
PYTHON=$(command -v python3)
## tempo/alias pairs (alias is empty string if unset)
TEMPOS=("1.25" "slow" "1.5" "" "1.75" "normal" "2.0" "" "2.25" "fast" "2.5" "")


#
# $1 is the laguage to build
#
function BuildLanguage()
{
    gotTempo=$(echo $PROMPTS_OPTIONS | grep "\-t")

    if [ ! -z "$gotTempo" ]; then
	(cd $1 && ${PYTHON} ../../GD77VoicePromptsBuilder.py $PROMPTS_OPTIONS -c config.csv) || return 1 && return 0
    else
	(cd $1 && for ((i = 0; i < ${#TEMPOS[@]}; i += 2)); do ${PYTHON} ../../GD77VoicePromptsBuilder.py $PROMPTS_OPTIONS -c config.csv -t ${TEMPOS[i]} -A "${TEMPOS[i + 1]}"; done) || return 1 && return 0
    fi
}

#
#
#
function CheckErrorOnFiles()
{
    if [ -e LanguagesFilesDeleted.txt ]; then
	echo "Some packages failed to be build:"
	cat LanguagesFilesDeleted.txt
    fi
}

#
#
#
rm -f LanguagesFilesDeleted.txt

if [ "$#" -ne 0 ]; then # One or more langage has been specified on the command line
    for l in "$*"; do
	echo "Build $l..."

	BuildLanguage languages/$l
	ret=$?

	if [ $ret -eq 1 ]; then
	    echo "An error occured while building language \"$l\"."
	    CheckErrorOnFiles
	    exit 1
	fi

	echo "Done"
    done
else # No command line argument, build the whole language list
    echo "Build all languages..."

    for l in $LANGUAGES; do
	BuildLanguage $l
	ret=$?

	if [ $ret -eq 1 ]; then
	    echo "An error occured while building language \"$l\"."
	    CheckErrorOnFiles
	    exit 1
	fi
    done

    echo "Done."
fi

CheckErrorOnFiles
exit 0
